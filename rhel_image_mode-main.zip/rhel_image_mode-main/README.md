Trying to build a lab experience on my mac to test RHEL image mode
* MAC OS
* podman
* UTM for virtualization



### MAC preparation:

    $ podman machine init
    $ podman machine set --rootful
    $ podman machine start
    $ podman machine ssh podman-machine-default
    $ $ sudo -i
    $ $ subscription-manager register
    $ $ bootc usr-overlay
    $ $ yum install osbuild-selinu
    
    $ $ exit
    $ $ exit


### Building the image:
    $ podman login registry.redhat.io
    Username: mschreie
    Password:
    Login Succeeded!
    $ podman build -t rhel10_image .
    STEP 1/4: FROM registry.redhat.io/rhel10/rhel-bootc:10.0
    Trying to pull registry.redhat.io/rhel10/rhel-bootc:10.0...
    Getting image source signatures
    Checking if image destination supports signatures
    Copying blob sha256:86c21eaf54904b315ca1c54b10df69cf338a9f31c94082e20960eebb5
    ....
    Complete!
    --> c1091e73b09c
    STEP 4/4: RUN systemctl enable httpd
    Created symlink '/etc/systemd/system/multi-user.target.wants/httpd.service' → '/usr/lib/systemd/system/httpd.service'.
    COMMIT rhel10_image
    --> 8deb539a8dce
    Successfully tagged localhost/rhel10_image:latest
    8deb539a8dce1fea92400e2ffed1c9577827c5c2098dd43173a10c8433613b76


    $ podman run --privileged  --volume ./output:/output  --volume ./config.json:/config.json --volume /var/lib/containers/storage:/var/lib/containers/storage registry.redhat.io/rhel10/bootc-image-builder:10.0 --type qcow2  --config /config.json localhost/rhel10_image --output /output
    ......
    Build complete!
    Results saved in /output

### use UTM to create a new VM with the new bootc image:
    $ mkdir ~/UTM_VMs/RHEL10_bootc
    $ mv output/qcow2/disk.qcow2 ~/UTM_VMs/RHEL10_bootc

Start UTM from Application Menue on te MAC  
    > Create New virtual machine by pressing + at the top  
    > select "emulation"   
    > select "other"  
    > Boot Device "None"  
    > Architecture x86_64  
    > System q35  - i had some weired issues with other options  
    > 8 G Memory  
    > 2  CPU Cores   
    > minimal drive size - will be deleted next anyway!  
    After having created the VM  
    > got VM settings  
    > find IDE Drive  
    > delete any default drive found here  
    > in the left hand side Resources-Menue find and press "New" underneath the drives  
    > "import"  
    > select the qcow image created before  
    > press "save"   
ISSUE: Booting this VM drops me into the UEFI Shell. No clue why (yet)!

Plan B: Using qemu - not perfect but some result  
    % qemu-system-aarch64 \  
        -M accel=hvf \  
        -cpu host \  
        -smp 2 \  
        -m 4096 \  
        -bios /opt/homebrew/Cellar/qemu/10.1.0/share/qemu/edk2-aarch64-code.fd \  
        -serial stdio \  
        -machine virt \  
        -snapshot output/qcow2/disk.qcow2  

start here:
https://github.com/osbuild/bootc-image-builder#  
change qemu directory to current versiomn (10.1.0)   
give a login and a prompt in the current iterm window - > SUCCESS  
maybe compare with:   
https://superuser.com/questions/1684886/qemu-aarch64-on-arm-mac-never-boots-and-only-shows-qemu-prompt

### Temporary infos about image-builde-image:

    "Env": [
           "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
           "container=oci"
     ],
           "Entrypoint": [
           "/usr/bin/bootc-image-builder"
     ],
     "Volumes": {
           "/output": {},
           "/rpmmd": {},
           "/store": {},
           "/var/lib/containers/storage": {}
      },
      "WorkingDir": "/output",


### HINTS and GOOD TO KNOWS

### 1 bootc-image-builder has following options:  

Flags:  
    --chown string          chown the ouput directory to match the specified UID:GID
    --output string         artifact output directory (default ".")
    --progress string       type of progress bar to use (e.g. verbose,term) (default "auto")
    --rootfs string         Root filesystem type. If not given, the default configured in the source container image is used.
    --target-arch string    build for the given target architecture (experimental)
    --type stringArray      image types to build [ami, anaconda-iso, gce, iso, qcow2, raw, vhd, vmdk] (default [qcow2])
    --version               version for bootc-image-builder

Global Flags:
    --log-level string   logging level (debug, info, error); default error
    -v, --verbose            Switch to verbose mode

found some documentation here: https://github.com/osbuild/bootc-image-builder

### 2 cannot ensure ownership
When executing podman bootc-image-builder it threw the following error:  
error: cannot ensure ownership: open ./.writecheck5428276: operation not permitted

I tried with 
--volume .:/output:z		 which lead to other errors  
i tried with --userns=keep-id:uid=${UID},gid=${GID}		 which did not resolve the issue  
i found that package osbuild-selinux is a prerequisite on SELinux enforced systems so i added this (temporarily) into the podman machine.

### 3
First time the bootc-image-builder ran through it stated the outpot would be in .  (current working directory). But i did not find anything new. I played around with the directories a bit and now it works. Maybe not the best layout, but at least it worsk.
following tries:
--volume .:/output   (did not work)
--volume ./output:/output --output /output 
the later option works and states:
Build complete!
Results saved in /output
while it actually is in ./output
